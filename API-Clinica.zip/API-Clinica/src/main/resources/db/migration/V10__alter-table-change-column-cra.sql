alter table administradores
change cra cfa varchar(15) not null unique;