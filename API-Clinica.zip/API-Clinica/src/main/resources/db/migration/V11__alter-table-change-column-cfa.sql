alter table administradores
drop index cfa;