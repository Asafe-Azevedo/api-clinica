alter table contabeis add ativo tinyint;
update medicos set ativo = 1;