package br.com.clinica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiClinicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiClinicaApplication.class, args);
	}

}
