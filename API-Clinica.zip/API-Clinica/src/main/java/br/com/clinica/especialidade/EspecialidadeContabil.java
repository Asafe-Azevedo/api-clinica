package br.com.clinica.especialidade;

public enum EspecialidadeContabil {

    AREA_FISCAL,
    AREA_CONTABIL,
    AREA_FINANCEIRA
}
