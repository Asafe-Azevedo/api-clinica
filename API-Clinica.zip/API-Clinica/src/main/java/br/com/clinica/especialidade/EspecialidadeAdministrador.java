package br.com.clinica.especialidade;

public enum EspecialidadeAdministrador {

    RECURSOS_HUMANOS,
    FINANCAS,
    MARKETING,
    ADMINISTRACAO_GERAL
}
