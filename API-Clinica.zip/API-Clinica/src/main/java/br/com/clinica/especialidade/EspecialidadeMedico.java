package br.com.clinica.especialidade;

public enum EspecialidadeMedico {

    ORTOPEDIA,
    CARDIOLOGIA,
    UROLOGISTA,
    GINECOLOGISTA
}
